config_io;
[eeg_ioObj, eeg_address] = EEG_trigger_code(); 

for i = 1:10
    sendTrigger(eeg_ioObj, eeg_address,i); %The line for sending trigger!
    WaitSecs(1);
end
