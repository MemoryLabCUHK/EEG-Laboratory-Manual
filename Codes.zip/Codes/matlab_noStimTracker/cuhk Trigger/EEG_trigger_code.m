function [eeg_ioObj, eeg_address] = EEG_trigger_code()
eeg_address = hex2dec('378'); %LPT1 output port address
eeg_ioObj = io64;       
status = io64(eeg_ioObj);
io64(eeg_ioObj, eeg_address, 0);   
end

function sendTrigger(eeg_ioObj, eeg_address,triggercode)
io64(eeg_ioObj, eeg_address, triggercode); %output command
WaitSecs(0.01); %wait a bit before resetting
io64(eeg_ioObj, eeg_address, 0); %reset trigger
end