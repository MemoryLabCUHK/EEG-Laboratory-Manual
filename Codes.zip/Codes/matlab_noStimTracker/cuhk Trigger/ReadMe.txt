This folder contains the files needed to send trigger on MATLAB. 

You may ignore everything and simply paste all these files to your experiment folder, together with your experiment script(s).
"CodeYouNeed.m" is a simple template/ demonstration of how send send a trigger to the ANT eeg computer.

	config_io;
	[eeg_ioObj, eeg_address] = EEG_trigger_code(); 

These two lines simply set up the environment for you to send the triggers.
The only thing that needs to be changed is 

	sendTrigger(eeg_ioObj, eeg_address,i);

where i refers to the trigger code you want to send.
By running this sample script, you should see the trigger "1", "2", "3"... "10" being sent every 1 second.

To incorperate this to your experiment script, simply put this line immediately after the line of code where you present the stimulus to the partcipant.