config_io;
[eeg_ioObj, eeg_address] = EEG_trigger_code(); 

for i = 1:10
    %play audio
    sendTrigger(eeg_ioObj, eeg_address,i);
    WaitSecs(1);
end
