function sendTrigger(eeg_ioObj, eeg_address,triggercode)
io64(eeg_ioObj, eeg_address, triggercode); %output command
WaitSecs(0.01); %wait a bit before resetting
io64(eeg_ioObj, eeg_address, 0); %reset trigger
end