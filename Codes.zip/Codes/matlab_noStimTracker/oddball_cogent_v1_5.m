% auditory oddball paradigm

%% preset
close all;
clear all;
sub=input('\subno\n');
config_display(1,3,[0 0 0],[1 1 1],'Calibri',60,7);
config_keyboard;
config_mouse;
config_sound;


%% trigger code in cogent
% trigger code
config_io;
ioObj=io64;
status=io64(ioObj);
address=hex2dec('0378');
outp(address,0);
%% trigger code in PTB
% initialization 
% if eeg_trigger_on_off 
%     config_io;
%     [eeg_ioObj, eeg_address] = EEG_trigger_code();
% end
%% generate sequence: 90% standard, 10% deviant 
% stim = zeros(300,1);
% % pseudorandom for test 
% 
% for round = 1:29
% rs=sum(clock)*1000;
% rs1=RandStream('mt19937ar','Seed',str2num([num2str(rs+round)]));
% D=randperm(rs1,4,1);
% stim((round-1)*10+6+D)=1;
% clear rs
% clear rs1
% end
stim = [1:255];
subname = ['.\stimuliOrder\oddball_RandMat' num2str(sub)];
save(subname,'stim');

%% begin experiment 
start_cogent;
preparestring('click to start',1,0,100);
preparestring('+',2,0,0); %buffer 2 for fixation point
preparestring('@',3,0,0);
% loadsound('standard.mp3',3);
preparepuretone(500,300,3);
preparestring('@',4,0,0);
% loadsound('deviant.mp3',4);
preparepuretone(800,300,4);
% triggertype=1;    
 %% start
drawpict(1);
waitmouse();
for ti = 1:length(stim)
    stimType = stim(ti);
    drawpict(2);
    wait(100);
     %----- trigger setting in cogent -----%
    trigger_stimuli = stimType;
    outp(address,trigger_stimuli); % �}trigger
     %----- trigger setting in PTB -----%
% tic
% if eeg_trigger_on_off
%     sendTrigger(eeg_ioObj, eeg_address, trigger_stimuli);
%     wait(10);
% end
% toc
        drawpict(3);
        playsound(3);
        waitsound(3);     
     outp(address,0);% ��trigger

    wait(400);

end

preparestring('this is the end of the experiment',5);
drawpict(5); %buffer 5 indicates the end 
wait(800);
stop_cogent;
clc;
            
