%%

clear all;
close all;
clc

%%

%This is a basic sample showing how to send digital output via XID.

%An exhaustive list of all commands written to the serial port in this
%example see https://cedrus.com/support/xid/commands.htm



clear device
% load('newDevice.mat');
% device = newDevice;
load('device_for2019b.mat');
%By default the pulse duration is set to 0, which is "indefinite".
%You can either set the necessary pulse duration, or simply lower the lines
%manually when desired.
setPulseDuration(device, 1000)

%mh followed by two bytes of a bitmask is how you raise/lower output lines.
%Not every XID device supports 16 bits of output, but you need to provide
%both bytes every time.
write(device,sprintf("mh%c%c", 255, 0), "char")

pause(2)

function byte = getByte(val, index)
    byte = bitand(bitshift(val,-8*(index-1)), 255);
end

function setPulseDuration(device, duration)
%mp sets the pulse duration on the XID device. The duration is a four byte
%little-endian integer.
    write(device, sprintf("mp%c%c%c%c", getByte(duration,1),...
        getByte(duration,2), getByte(duration,3),...
        getByte(duration,4)), "char")
end
